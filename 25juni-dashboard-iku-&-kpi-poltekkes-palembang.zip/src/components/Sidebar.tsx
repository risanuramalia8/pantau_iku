import { useState } from 'react';
import { UserSession } from '../types';
import { 
  BarChart3, 
  ShieldAlert, 
  Settings, 
  FileSpreadsheet, 
  LogOut, 
  User, 
  LogIn,
  Key,
  Database,
  Briefcase,
  ChevronLeft
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: UserSession | null;
  onLogout: () => void;
  onLoginClick: () => void;
  isVisible: boolean;
  onToggleVisibility: (visible: boolean) => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  currentUser,
  onLogout,
  onLoginClick,
  isVisible,
  onToggleVisibility,
}: SidebarProps) {
  const [showRoleHint, setShowRoleHint] = useState(false);
  const [isLoginExpanded, setIsLoginExpanded] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard & Ringkasan', icon: BarChart3 },
    { id: 'indicators', label: 'Indikator (IKU & KPI)', icon: FileSpreadsheet },
  ];

  if (currentUser) {
    menuItems.push({ id: 'input', label: 'Update Capaian (PJ)', icon: Settings });
  }

  return (
    <aside 
      id="sidebar-container"
      className={`transition-all duration-300 ease-in-out bg-slate-900 text-white min-h-screen flex flex-col justify-between shrink-0 shadow-xl border-r border-slate-800 ${
        isVisible ? 'w-80 opacity-100' : 'w-0 opacity-0 overflow-hidden border-r-0'
      }`}
    >
      <div className="flex flex-col w-80">
        {/* Brand / Header */}
        <div className="p-6 border-b border-slate-800 bg-kemenkes-toska-dark/15 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-kemenkes-toska rounded-xl text-slate-950 shadow-md shadow-kemenkes-toska/20">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-sans font-bold text-lg tracking-tight text-white leading-tight">
                MONEV POLTEKKES
              </h1>
              <p className="text-xs font-mono text-kemenkes-kuning-dark tracking-wider">
                PALEMBANG • KEMENKES
              </p>
            </div>
          </div>
          <button
            id="sidebar-collapse-btn"
            onClick={() => onToggleVisibility(false)}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Sembunyikan Menu"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* User Card */}
        <div className="m-4 rounded-xl border border-slate-800 bg-slate-800/40 flex flex-col overflow-hidden">
          {currentUser ? (
            <div className="p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-kemenkes-toska-dark/30 border border-kemenkes-toska/30 flex items-center justify-center text-kemenkes-toska-light font-bold">
                  {currentUser.username.substring(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-semibold truncate text-slate-100">{currentUser.username}</h4>
                  <p className="text-xs text-slate-400 font-mono capitalize">{currentUser.role === 'admin' ? 'Super Admin' : 'PJ Unit'}</p>
                </div>
              </div>
              <div className="mt-1 pt-2 border-t border-slate-700/50 flex flex-col gap-1 text-[11px] text-slate-400 font-mono">
                <div className="flex justify-between">
                  <span>Akses:</span>
                  <span className="text-kemenkes-kuning-dark font-semibold">{currentUser.pjCode === 'all' ? 'Seluruh Unit' : currentUser.pjCode}</span>
                </div>
              </div>
              <button
                onClick={onLogout}
                className="mt-2 w-full flex items-center justify-center gap-2 py-1.5 px-3 bg-red-950/40 hover:bg-red-900/40 text-red-400 text-xs font-medium rounded-lg border border-red-900/50 hover:border-red-800 transition-all cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                Keluar Sistem
              </button>
            </div>
          ) : (
            <div className="flex flex-col">
              {/* Collapsed view header */}
              <button
                id="toggle-login-area-btn"
                onClick={() => setIsLoginExpanded(!isLoginExpanded)}
                className="w-full flex items-center justify-between p-3.5 bg-slate-800/80 hover:bg-slate-800 transition-colors text-left text-xs font-bold text-slate-200 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <LogIn className="w-3.5 h-3.5 text-kemenkes-toska" />
                  <span>Sesi Unit / Admin</span>
                </div>
                <span className="text-[10px] font-mono text-kemenkes-kuning bg-slate-900/60 px-1.5 py-0.5 rounded text-slate-950 font-black">
                  {isLoginExpanded ? 'Minimize' : 'Klik'}
                </span>
              </button>

              {isLoginExpanded && (
                <div id="login-expanded-area" className="p-4 border-t border-slate-800 bg-slate-800/30 flex flex-col gap-3 animate-fade-in transition-all">
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Gunakan akun unit kerja atau admin untuk mengupdate data capaian bulanan.
                  </p>
                  <button
                    onClick={onLoginClick}
                    className="flex items-center justify-center gap-2 py-2 px-4 bg-kemenkes-toska hover:bg-kemenkes-toska-hover text-slate-950 text-xs font-bold rounded-lg shadow-lg shadow-kemenkes-toska/10 cursor-pointer transition-all active:scale-[0.98]"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    Masuk Port
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="px-4 py-2 flex flex-col gap-1.5">
          <p className="text-[10px] uppercase tracking-wider text-slate-500 font-mono px-2 mb-1">
            Menu Utama
          </p>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-3.5 py-3 px-3.5 rounded-xl text-sm font-medium transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-kemenkes-toska text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Info */}
      <div className="p-6 border-t border-slate-800/50 bg-slate-950/20 text-center flex flex-col gap-2 text-slate-500">
        <div className="flex justify-center gap-2 items-center">
          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
          <span className="text-[10px] font-mono tracking-wider text-slate-400">EARLY WARNING SYST.</span>
        </div>
        <p className="text-[11px]">Direktorat Poltekkes Palembang</p>
        <p className="text-[9px] font-mono text-slate-600">v1.2.0-secure-api</p>
      </div>
    </aside>
  );
}
