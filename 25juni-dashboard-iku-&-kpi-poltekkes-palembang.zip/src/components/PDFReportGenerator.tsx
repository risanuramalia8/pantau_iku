import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { Achievement } from '../types';
import { Download, FileText } from 'lucide-react';
import { useState } from 'react';

interface PDFReportGeneratorProps {
  achievements: Achievement[];
}

export default function PDFReportGenerator({ achievements }: PDFReportGeneratorProps) {
  const [generating, setGenerating] = useState(false);

  const exportPDF = () => {
    setGenerating(true);
    try {
      const doc = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
      }) as any;

      const totalIKU = achievements.filter(a => a.type === 'IKU');
      const totalKPI = achievements.filter(a => a.type === 'KPI');
      
      const checkIsMet = (item: Achievement) => {
        const val = item.realValues.tw1;
        if (val === null) return false;
        return val >= item.targetNum;
      };

      const metIKU = totalIKU.filter(checkIsMet).length;
      const metKPI = totalKPI.filter(checkIsMet).length;

      // --- Header / Kop Surat ---
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.text('KEMENTERIAN KESEHATAN REPUBLIK INDONESIA', 105, 15, { align: 'center' });
      doc.setFontSize(11);
      doc.text('DIREKTORAT POLITEKNIK KESEHATAN PALEMBANG', 105, 21, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text('Jalan Sukabangun I No. 1150, Palembang, Sumatera Selatan', 105, 26, { align: 'center' });
      doc.text('Telepon: (0711) 410063 | Fax: (0711) 410063', 105, 30, { align: 'center' });
      
      // Double Line Divider
      doc.setLineWidth(1);
      doc.line(15, 33, 195, 33);
      doc.setLineWidth(0.3);
      doc.line(15, 34, 195, 34);

      // --- Title ---
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text('LAPORAN CAPAIAN TARGET KINERJA (IKU & KPI)', 105, 43, { align: 'center' });
      doc.setFontSize(10);
      doc.text('Periode Laporan: Triwulan I 2026', 105, 49, { align: 'center' });

      // --- Summary Grid Block ---
      doc.setFillColor(243, 244, 246);
      doc.rect(15, 55, 180, 26, 'F');
      
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text('RINGKASAN CAPAIAN KINERJA:', 20, 61);
      
      doc.setFont('helvetica', 'normal');
      doc.text(`* Total Indikator Utama (IKU) : ${totalIKU.length} mtr (Tercapai: ${metIKU} mtr, Rasio: ${totalIKU.length ? Math.round((metIKU/totalIKU.length)*100) : 0}%)`, 20, 68);
      doc.text(`* Total Indikator Layanan (KPI) : ${totalKPI.length} mtr (Tercapai: ${metKPI} mtr, Rasio: ${totalKPI.length ? Math.round((metKPI/totalKPI.length)*100) : 0}%)`, 20, 74);

      // --- Data Table (jsPDF-autotable) ---
      const tableRows = achievements.map((item, index) => {
        const isMet = checkIsMet(item) ? 'TERCAPAI' : 'DI BAWAH TARGET';
        return [
          (index + 1).toString(),
          item.type,
          item.code,
          item.name,
          item.targetYearly,
          item.realisation.tw1 || '-',
          isMet,
          `${item.pjCode} (${item.pjDetail})`
        ];
      });

      doc.autoTable({
        startY: 88,
        head: [['No', 'Tipe', 'Kode', 'Indikator Capaian Kinerja', 'Target', 'Realisasi TW I', 'Status', 'PJ Unit Kerja']],
        body: tableRows,
        theme: 'striped',
        styles: {
          fontSize: 8,
          cellPadding: 2,
        },
        headStyles: {
          fillColor: [0, 169, 157], // Kemenkes Teal Green
          textColor: [255, 255, 255],
          fontStyle: 'bold',
        },
        columnStyles: {
          0: { cellWidth: 8, halign: 'center' },
          1: { cellWidth: 12, halign: 'center' },
          2: { cellWidth: 15, halign: 'center' },
          3: { cellWidth: 60 },
          4: { cellWidth: 22, halign: 'center' },
          5: { cellWidth: 22, halign: 'center' },
          6: { cellWidth: 24, halign: 'center' },
          7: { cellWidth: 32 }
        },
        didDrawPage: (data: any) => {
          // Footer Page Number
          const str = 'Halaman ' + doc.internal.getNumberOfPages();
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text(str, 195, 285, { align: 'right' });
        }
      });

      // Saving
      doc.save(`Laporan_Monev_Kinerja_Poltekkes_Palembang_TW1_2026.pdf`);
    } catch (err: any) {
      console.error(err);
      alert('Gagal mengekspor PDF format otomatis: ' + err.message);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <button
      onClick={exportPDF}
      disabled={generating}
      className="flex items-center gap-2 py-2 px-4.5 bg-kemenkes-toska hover:bg-kemenkes-toska-hover text-slate-950 font-black rounded-xl shadow-lg shadow-kemenkes-toska/15 cursor-pointer transition-all active:scale-95 disabled:opacity-50 text-xs"
    >
      <FileText className="w-4 h-4" />
      {generating ? 'Mengunduh PDF...' : 'Unduh Laporan PDF'}
    </button>
  );
}
