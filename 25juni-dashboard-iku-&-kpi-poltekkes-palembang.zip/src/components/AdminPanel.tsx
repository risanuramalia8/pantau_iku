import { useState, FormEvent } from 'react';
import { Achievement, UserSession } from '../types';
import { 
  Save, 
  Settings, 
  User, 
  HelpCircle, 
  PenTool, 
  Globe, 
  Clock, 
  ShieldCheck, 
  Briefcase,
  AlertCircle,
  FileText
} from 'lucide-react';

interface AdminPanelProps {
  achievements: Achievement[];
  currentUser: UserSession;
  onUpdateIndicator: (id: string, updatedFields: Partial<Achievement>) => Promise<boolean>;
}

export default function AdminPanel({
  achievements,
  currentUser,
  onUpdateIndicator,
}: AdminPanelProps) {
  const [selectedId, setSelectedId] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form states
  const [tw1, setTw1] = useState('');
  const [tw2, setTw2] = useState('');
  const [tw3, setTw3] = useState('');
  const [tw4, setTw4] = useState('');
  const [supportLink, setSupportLink] = useState('');
  const [justification, setJustification] = useState('');
  const [kendala, setKendala] = useState('');
  
  // Monthly Trends
  const [mJan, setMJan] = useState('');
  const [mFeb, setMFeb] = useState('');
  const [mMar, setMMar] = useState('');
  const [mApr, setMApr] = useState('');
  const [mMay, setMMay] = useState('');
  const [mJun, setMJun] = useState('');

  // Target editing (admin only)
  const [targetYearly, setTargetYearly] = useState('');
  const [targetNum, setTargetNum] = useState('');

  // Filtering indicators editable by this logged-in user
  const editableIndicators = achievements.filter((item) => {
    if (currentUser.pjCode === 'all') return true; // Admin can edit all
    return item.pjCode === currentUser.pjCode;    // Unit can only edit their division
  });

  const handleSelectIndicator = (id: string) => {
    setSelectedId(id);
    setStatusMsg(null);
    const item = achievements.find(a => a.id === id);
    if (!item) return;

    // Populate values
    setTw1(item.realisation.tw1 || '');
    setTw2(item.realisation.tw2 || '');
    setTw3(item.realisation.tw3 || '');
    setTw4(item.realisation.tw4 || '');
    setSupportLink(item.supportLink || '');
    setJustification(item.justification || '');
    setKendala(item.kendala || '');
    
    // Monthly
    setMJan(item.monthlyTrend.Jan !== null ? String(item.monthlyTrend.Jan) : '');
    setMFeb(item.monthlyTrend.Feb !== null ? String(item.monthlyTrend.Feb) : '');
    setMMar(item.monthlyTrend.Mar !== null ? String(item.monthlyTrend.Mar) : '');
    setMApr(item.monthlyTrend.Apr !== null ? String(item.monthlyTrend.Apr) : '');
    setMMay(item.monthlyTrend.May !== null ? String(item.monthlyTrend.May) : '');
    setMJun(item.monthlyTrend.Jun !== null ? String(item.monthlyTrend.Jun) : '');

    // Target
    setTargetYearly(item.targetYearly || '');
    setTargetNum(String(item.targetNum || ''));
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedId) return;

    setIsSaving(true);
    setStatusMsg(null);

    const item = achievements.find(a => a.id === selectedId);
    if (!item) {
      setIsSaving(false);
      return;
    }

    // Build update payload
    const payload: Partial<Achievement> = {
      realisation: {
        tw1: tw1 === '' ? null : tw1,
        tw2: tw2 === '' ? null : tw2,
        tw3: tw3 === '' ? null : tw3,
        tw4: tw4 === '' ? null : tw4,
      },
      supportLink: supportLink === '' ? '-' : supportLink,
      justification: justification,
      kendala: kendala,
      monthlyTrend: {
        ...item.monthlyTrend,
        Jan: mJan === '' ? null : Number(mJan),
        Feb: mFeb === '' ? null : Number(mFeb),
        Mar: mMar === '' ? null : Number(mMar),
        Apr: mApr === '' ? null : Number(mApr),
        May: mMay === '' ? null : Number(mMay),
        Jun: mJun === '' ? null : Number(mJun),
      },
    };

    // Include target if admin
    if (currentUser.role === 'admin') {
      payload.targetYearly = targetYearly;
      payload.targetNum = targetNum === '' ? 0 : Number(targetNum);
    }

    // Call callback update
    const success = await onUpdateIndicator(selectedId, payload);
    if (success) {
      setStatusMsg({ type: 'success', text: 'Capaian indikator berhasil disimpan dan didokumentasikan.' });
    } else {
      setStatusMsg({ type: 'error', text: 'Gagal memperbarui data. Cek otorisasi atau koneksi API.' });
    }
    setIsSaving(false);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 flex flex-col gap-6">
      
      {/* Title Header */}
      <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
        <div className="p-2.5 bg-kemenkes-toska-light text-kemenkes-toska-dark rounded-xl">
          <Settings className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-base font-bold text-slate-900">Input Capaian Kinerja Unit Kerja</h3>
          <p className="text-xs text-slate-500 mt-0.5">Otoritas pelaporan unit: <span className="text-kemenkes-toska-dark font-extrabold">{currentUser.pjCode === 'all' ? 'Seluruh Komponen (Super Admin)' : currentUser.pjCode}</span></p>
        </div>
      </div>

      {editableIndicators.length === 0 ? (
        <div className="p-8 text-center text-slate-500 bg-slate-50 rounded-xl border border-slate-100 flex flex-col items-center justify-center gap-2">
          <AlertCircle className="w-8 h-8 text-slate-400" />
          <p className="font-semibold text-sm">Tidak Ada Indikator Ditugaskan</p>
          <p className="text-xs">Unit kerja Anda tidak bertanggung jawab sebagai PJ IKU atau KPI.</p>
        </div>
      ) : (
        <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column: Selector */}
          <div className="lg:col-span-4 flex flex-col gap-2.5">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold block">
              Pilih Indikator Kinerja Yang Dilaporkan
            </label>
            <div className="flex flex-col gap-1.5 max-h-[460px] overflow-y-auto pr-2 bg-slate-50/50 p-2.5 rounded-xl border border-slate-200/60">
              {editableIndicators.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectIndicator(item.id)}
                  className={`text-left p-3 rounded-lg text-xs leading-tight transition-all text-slate-700 cursor-pointer ${
                    selectedId === item.id 
                      ? 'bg-kemenkes-toska text-slate-950 font-bold shadow-md shadow-kemenkes-toska/20' 
                      : 'hover:bg-slate-200/60 bg-white border border-slate-200/50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-[9px] font-mono tracking-wide">
                    <span className={selectedId === item.id ? 'text-slate-950 font-bold' : 'text-kemenkes-toska-dark'}>{item.code}</span>
                    <span>•</span>
                    <span className="opacity-80">{item.pjDetail}</span>
                  </div>
                  <p className="line-clamp-2">{item.name}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Dynamic Form */}
          <div className="lg:col-span-8">
            {!selectedId ? (
              <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-slate-400 gap-2 border-2 border-dashed border-slate-200 bg-slate-50/30 rounded-2xl p-6 text-center">
                <PenTool className="w-10 h-10 text-slate-300" />
                <p className="font-bold text-sm text-slate-600">Pilih Indikator di Sebelah Kiri</p>
                <p className="text-xs max-w-xs">Pilihlah salah satu dari daftar IKU atau KPI untuk mulai memperbaharui angka realisasi, tautan dukung dokumen, penjelasan, dan kendala lapangan.</p>
              </div>
            ) : (
              <div className="flex flex-col gap-5">
                
                {statusMsg && (
                  <div className={`p-4 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                    statusMsg.type === 'success' ? 'bg-kemenkes-toska-light text-[#006e66] border border-kemenkes-toska/30' : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}>
                    {statusMsg.type === 'success' && <ShieldCheck className="w-4.5 h-4.5 text-kemenkes-toska-dark" />}
                    {statusMsg.text}
                  </div>
                )}

                {/* KPI/IKU Details Summary bar */}
                <div className="p-3.5 bg-slate-100 rounded-xl border border-slate-200 flex flex-col gap-1 text-[11px] text-slate-600">
                  <div className="flex justify-between font-mono">
                    <span>TIPE INDIKATOR:</span>
                    <span className="font-extrabold text-kemenkes-toska-dark">
                      {achievements.find(a => a.id === selectedId)?.type} ({achievements.find(a => a.id === selectedId)?.code})
                    </span>
                  </div>
                  <div className="mt-1 font-semibold text-slate-800 leading-tight">
                    {achievements.find(a => a.id === selectedId)?.name}
                  </div>
                </div>

                {/* TARGET SECTION (ADMIN ONLY) */}
                {currentUser.role === 'admin' && (
                  <div className="p-4 bg-kemenkes-toska-light/50 border border-kemenkes-toska/20 rounded-xl grid grid-cols-2 gap-4">
                    <div className="col-span-2 text-[10px] font-mono font-bold text-kemenkes-toska-dark uppercase">
                      PENGATURAN TARGET (Hanya Super Admin)
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Target Tahunan (Teks / Unit)</label>
                      <input
                        type="text"
                        value={targetYearly}
                        onChange={(e) => setTargetYearly(e.target.value)}
                        placeholder="Contoh: 66,02% atau 48 Penelitian"
                        className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Target Angka (Normatif)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={targetNum}
                        onChange={(e) => setTargetNum(e.target.value)}
                        placeholder="Contoh: 66.02 atau 48"
                        className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* TW REALISASI DATA INPUT */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/60">
                  <div className="col-span-full text-[10px] font-mono font-bold text-slate-500 uppercase">
                    INPUT REALISASI TRIWULAN (TW)
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Realisasi TW I</label>
                    <input
                      type="text"
                      value={tw1}
                      onChange={(e) => setTw1(e.target.value)}
                      placeholder="Contoh: 43,08%"
                      className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">TW II (Opsional)</label>
                    <input
                      type="text"
                      value={tw2}
                      onChange={(e) => setTw2(e.target.value)}
                      placeholder="-"
                      className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">TW III (Opsional)</label>
                    <input
                      type="text"
                      value={tw3}
                      onChange={(e) => setTw3(e.target.value)}
                      placeholder="-"
                      className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">TW IV (Opsional)</label>
                    <input
                      type="text"
                      value={tw4}
                      onChange={(e) => setTw4(e.target.value)}
                      placeholder="-"
                      className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    />
                  </div>
                </div>

                {/* HISTORIS TREN BULANAN INPUT */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/60">
                  <div className="col-span-full text-[10px] font-mono font-bold text-slate-500 uppercase flex justify-between items-center">
                    <span>PROGRESS BULANAN (ANGKA SAJA GUNA CHART)</span>
                    <span className="text-[9px] text-amber-600 normal-case font-semibold">Jan-Jun Semester 1</span>
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">JAN</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mJan}
                      onChange={(e) => setMJan(e.target.value)}
                      placeholder="e.g. 15"
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">FEB</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mFeb}
                      onChange={(e) => setMFeb(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">MAR</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mMar}
                      onChange={(e) => setMMar(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">APR</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mApr}
                      onChange={(e) => setMApr(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">MAY</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mMay}
                      onChange={(e) => setMMay(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 font-mono block mb-1 text-center">JUN</label>
                    <input
                      type="number"
                      step="0.01"
                      value={mJun}
                      onChange={(e) => setMJun(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-1 text-center font-mono"
                    />
                  </div>
                </div>

                {/* CONTEXT LOGS DUKUNG */}
                <div className="flex flex-col gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                      <Globe className="w-3.5 h-3.5 text-slate-400" />
                      Tautan/URL Dokumen Data Dukung (Google Drive / Spreadsheet)
                    </label>
                    <input
                      type="url"
                      value={supportLink}
                      onChange={(e) => setSupportLink(e.target.value)}
                      placeholder="https://drive.google.com/..."
                      className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-slate-400" />
                      Rincian Penjelasan Capaian (Justifikasi)
                    </label>
                    <textarea
                      value={justification}
                      onChange={(e) => setJustification(e.target.value)}
                      placeholder="Tuliskan justifikasi perolehan data..."
                      rows={3}
                      className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska leading-normal"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                      Kendala Lapangan / Hambatan Yang Dihadapi
                    </label>
                    <textarea
                      value={kendala}
                      onChange={(e) => setKendala(e.target.value)}
                      placeholder="Sebutkan hambatan yang terjadi agar dapat dianalisis oleh Early Warning System..."
                      rows={2}
                      className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska leading-normal border-rose-100"
                    />
                  </div>
                </div>

                {/* BUTTON FORM ACTION */}
                <div className="border-t border-slate-100 pt-4 flex justify-end">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex items-center gap-2 py-2.5 px-6 bg-kemenkes-toska hover:bg-kemenkes-toska-hover text-slate-950 font-bold rounded-xl shadow-lg shadow-kemenkes-toska/15 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    {isSaving ? 'Menyimpan Berkas...' : 'Simpan Laporan Capaian'}
                  </button>
                </div>

              </div>
            )}
          </div>
          
        </form>
      )}

    </div>
  );
}
