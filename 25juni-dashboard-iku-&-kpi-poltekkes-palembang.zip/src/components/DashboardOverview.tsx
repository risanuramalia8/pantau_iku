import { useState } from 'react';
import { Achievement } from '../types';
import { 
  ShieldAlert, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  AlertTriangle,
  FileSpreadsheet,
  ChevronRight,
  Award,
  Activity
} from 'lucide-react';

interface DashboardOverviewProps {
  achievements: Achievement[];
  onFocusIndicator: (code: string) => void;
  openaiEnabled?: boolean;
}

export default function DashboardOverview({
  achievements,
  onFocusIndicator,
}: DashboardOverviewProps) {
  const [dashboardFilter, setDashboardFilter] = useState<'all' | 'iku' | 'kpi'>('all');

  // Helper check if target met
  const checkIsMet = (item: Achievement) => {
    const val = item.realValues.tw1;
    if (val === null) return false;
    return val >= item.targetNum;
  };

  // Base list calculations
  const ikuItems = achievements.filter(a => a.type === 'IKU');
  const kpiItems = achievements.filter(a => a.type === 'KPI');

  const ikuMet = ikuItems.filter(checkIsMet).length;
  const kpiMet = kpiItems.filter(checkIsMet).length;

  const ikuSuccessRate = ikuItems.length > 0 ? Math.round((ikuMet / ikuItems.length) * 100) : 0;
  const kpiSuccessRate = kpiItems.length > 0 ? Math.round((kpiMet / kpiItems.length) * 100) : 0;

  // Filtered lists based on chosen dashboard
  const currentItems = achievements.filter(a => {
    if (dashboardFilter === 'iku') return a.type === 'IKU';
    if (dashboardFilter === 'kpi') return a.type === 'KPI';
    return true;
  });

  const currentMetItems = currentItems.filter(checkIsMet);
  const currentUnderperformingItems = currentItems.filter(a => !checkIsMet(a));

  const currentMetCount = currentMetItems.length;
  const currentUnderperformingCount = currentUnderperformingItems.length;
  const currentTotalCount = currentItems.length;
  const currentSuccessRate = currentTotalCount > 0 ? Math.round((currentMetCount / currentTotalCount) * 100) : 0;

  return (
    <div className="flex flex-col gap-6 animate-fade-in" id="dashboard-system-root">
      
      {/* Banner / Title Page */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-kemenkes-toska-dark to-slate-900 text-white shadow-lg relative overflow-hidden flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" id="banner-section">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center pr-6 pointer-events-none">
          <TrendingUp className="w-56 h-56 transform rotate-12" id="banner-icon-bg" />
        </div>
        <div className="z-10" id="banner-text-block">
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#cce111] bg-kemenkes-toska-dark/35 px-2.5 py-1 rounded-full font-extrabold border border-kemenkes-toska/30" id="banner-tag">
            Sistem Pemantauan Capaian
          </span>
          <h2 className="text-2xl font-bold mt-2.5 tracking-tight font-display text-kemenkes-putih" id="banner-heading">
            Dashboard Integritas Kinerja Poltekkes Palembang
          </h2>
          <p className="text-slate-300 text-xs mt-1.5 max-w-xl" id="banner-paragraph">
            Sistem deteksi dini peningkatan mutu Tridharma Perguruan Tinggi dan efisiensi tata kelola BLU triwulanan secara transparan.
          </p>
        </div>
        <div className="py-2 px-4 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center gap-3 shrink-0 text-xs font-mono" id="banner-time-block">
          <Clock className="w-4 h-4 text-kemenkes-kuning" id="banner-clock-icon" />
          <div>
            <p className="text-slate-400 text-[10px]" id="banner-time-label">TANGGAL LAPORAN</p>
            <p className="text-white font-semibold" id="banner-time-value">Triwulan I 2026 (Aktif)</p>
          </div>
        </div>
      </div>

      {/* Tab Selector untuk Pemisahan Dashboard IKU & KPI */}
      <div className="flex flex-col gap-1.5" id="tab-nav-wrapper">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider pl-1" id="tab-nav-label">
          Pilih Tampilan Kinerja (Dashboard View)
        </label>
        <div className="bg-slate-100 p-1.5 rounded-2xl border border-slate-200 w-full sm:w-max flex flex-col sm:flex-row gap-1" id="tab-button-group">
          <button
            id="tab-all-btn"
            onClick={() => setDashboardFilter('all')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl cursor-pointer transition-all duration-150 ${
              dashboardFilter === 'all'
                ? 'bg-kemenkes-toska text-slate-950 shadow-md font-extrabold'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200/50'
            }`}
          >
            📊 Gabungan Capaian Kinerja (IKU & KPI)
          </button>
          <button
            id="tab-iku-btn"
            onClick={() => setDashboardFilter('iku')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl cursor-pointer transition-all duration-150 ${
              dashboardFilter === 'iku'
                ? 'bg-kemenkes-toska text-slate-950 shadow-md font-bold'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200/50'
            }`}
          >
            🎯 Dashboard IKU Poltekkes
          </button>
          <button
            id="tab-kpi-btn"
            onClick={() => setDashboardFilter('kpi')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl cursor-pointer transition-all duration-150 ${
              dashboardFilter === 'kpi'
                ? 'bg-kemenkes-toska text-slate-950 shadow-md font-bold'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200/50'
            }`}
          >
            💼 Dashboard KPI Ketua BLU
          </button>
        </div>
      </div>

      {/* Dynamic Bento Grid Stats Cards based on Filter */}
      {dashboardFilter === 'all' ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="stats-grid-all">
          {/* IKU Overview Card */}
          <div className="p-5 rounded-2xl bg-kemenkes-putih border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="iku-all-card">
            <div className="flex justify-between items-start">
              <span className="text-[11px] font-mono font-bold tracking-wider text-kemenkes-toska-dark bg-kemenkes-toska-light px-2.5 py-1 rounded-lg">
                IKU POLTEKKES
              </span>
              <FileSpreadsheet className="w-5 h-5 text-slate-400" />
            </div>
            <div className="mt-4">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-slate-900">{ikuMet}</span>
                <span className="text-slate-400 text-xs">/ {ikuItems.length} Indikator</span>
              </div>
              <div className="mt-3.5 flex items-center gap-2">
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-kemenkes-toska h-2 rounded-full transition-all duration-300"
                    style={{ width: `${ikuSuccessRate}%` }}
                  ></div>
                </div>
                <span className="text-xs font-bold font-mono text-kemenkes-toska-dark">{ikuSuccessRate}%</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 mt-2">Target Triwulan I Terlampaui</p>
          </div>

          {/* KPI Overview Card */}
          <div className="p-5 rounded-2xl bg-kemenkes-putih border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="kpi-all-card">
            <div className="flex justify-between items-start">
              <span className="text-[11px] font-mono font-bold tracking-wider text-kemenkes-kuning-deep bg-kemenkes-kuning-light px-2.5 py-1 rounded-lg border border-kemenkes-kuning-dark/20">
                KPI KETUA BLU
              </span>
              <CheckCircle2 className="w-5 h-5 text-slate-400" />
            </div>
            <div className="mt-4">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-slate-950">{kpiMet}</span>
                <span className="text-slate-400 text-xs">/ {kpiItems.length} Indikator</span>
              </div>
              <div className="mt-3.5 flex items-center gap-2">
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-kemenkes-kuning h-2 rounded-full transition-all duration-300"
                    style={{ width: `${kpiSuccessRate}%` }}
                  ></div>
                </div>
                <span className="text-xs font-bold font-mono text-kemenkes-kuning-deep">{kpiSuccessRate}%</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 mt-2">Target Triwulan I Terlampaui</p>
          </div>

          {/* Total Terpenuhi */}
          <div className="p-5 rounded-2xl bg-kemenkes-putih border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="total-all-card">
            <div>
              <p className="text-xs font-mono text-slate-500 uppercase">Capaian Terpenuhi</p>
              <h3 className="text-3xl font-extrabold text-kemenkes-toska-dark mt-2 flex items-baseline gap-1" id="total-capaian-count">
                {ikuMet + kpiMet}
                <span className="text-xs font-normal text-slate-400">/ {achievements.length}</span>
              </h3>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex justify-between text-xs">
              <span className="text-slate-400">Sinergi Kinerja:</span>
              <span className="font-extrabold text-[#0db9ac]" id="status-on-track">On Track</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-2">Capaian akumulasi Tridharma & Keuangan BLU.</p>
          </div>

          {/* Early Warning Alert Count */}
          <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="mitigasi-all-card">
            <div>
              <p className="text-xs font-mono text-amber-800 uppercase flex items-center gap-1.5" id="label-sinyal">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                Sinyal Mitigasi (EW)
              </p>
              <h3 className="text-3xl font-bold text-amber-600 mt-2 flex items-baseline gap-1" id="sinyal-qty">
                {currentUnderperformingCount}
                <span className="text-xs font-normal text-amber-500">rawan capaian</span>
              </h3>
            </div>
            <div className="mt-2 text-xs text-amber-750/80 leading-snug">
              {currentUnderperformingCount > 0
                ? `Terdapat ${currentUnderperformingCount} rincian kegiatan butuh percepatan target.`
                : 'Sistem mendeteksi semua sasaran aman.'}
            </div>
            <p className="text-[10px] text-amber-600/80 mt-2">Early Warning System terdeteksi.</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="stats-grid-specific">
          {/* Card 1: Met vs Total */}
          <div className="p-5 rounded-2xl bg-kemenkes-putih border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="specific-met-card">
            <div className="flex justify-between items-start">
              <span className="text-[11px] font-mono font-bold tracking-wider text-kemenkes-toska-dark bg-kemenkes-toska-light px-2.5 py-1 rounded-lg">
                STATUS SASARAN {dashboardFilter.toUpperCase()}
              </span>
              <Award className="w-5 h-5 text-slate-400" />
            </div>
            <div className="mt-4">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-slate-950">{currentMetCount}</span>
                <span className="text-slate-400 text-xs">/ {currentTotalCount} Indikator Terpenuhi</span>
              </div>
              <div className="mt-3.5 flex items-center gap-2">
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-kemenkes-toska h-2 rounded-full"
                    style={{ width: `${currentSuccessRate}%` }}
                  ></div>
                </div>
                <span className="text-xs font-bold font-mono text-kemenkes-toska-dark">{currentSuccessRate}%</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-500 mt-2">Rasio keberhasilan unit untuk program {dashboardFilter.toUpperCase()}.</p>
          </div>

          {/* Card 2: Success Rate Gauge Styling */}
          <div className="p-5 rounded-2xl bg-kemenkes-putih border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="specific-percent-card">
            <div className="flex justify-between items-start">
              <span className="text-[11px] font-mono font-bold tracking-wider text-kemenkes-kuning-deep bg-kemenkes-kuning-light px-2.5 py-1 rounded-lg">
                PERSENTASE CAPAIAN
              </span>
              <Activity className="w-5 h-5 text-slate-400" />
            </div>
            <div className="mt-4 flex items-center gap-4">
              <div className="relative flex items-center justify-center shrink-0" id="gauge-container">
                <svg className="w-16 h-16 transform -rotate-90">
                  <circle cx="32" cy="32" r="28" className="stroke-slate-100 fill-none" strokeWidth="6" />
                  <circle 
                    cx="32" 
                    cy="32" 
                    r="28" 
                    className="stroke-kemenkes-toska fill-none" 
                    strokeWidth="6" 
                    strokeDasharray={2 * Math.PI * 28}
                    strokeDashoffset={2 * Math.PI * 28 * (1 - currentSuccessRate / 100)}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="absolute text-xs font-bold font-mono text-slate-900">{currentSuccessRate}%</span>
              </div>
              <div>
                <p className="text-sm font-extrabold text-slate-800">Efisiensi Mutu Terjamin</p>
                <p className="text-[10px] text-slate-500 mt-0.5">Nilai presentasi dihitung dari target Triwulan I.</p>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 mt-2">Klasifikasi: Kategori Baik dan Terpenuhi.</p>
          </div>

          {/* Card 3: Mitigasi Khusus */}
          <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between" id="specific-mitigasi-card">
            <div>
              <p className="text-xs font-mono text-amber-800 uppercase flex items-center gap-1.5" id="specific-warning-title">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                Mitigasi Hambatan ({dashboardFilter.toUpperCase()})
              </p>
              <h3 className="text-3xl font-extrabold text-amber-600 mt-2 flex items-baseline gap-1" id="specific-warning-body">
                {currentUnderperformingCount}
                <span className="text-xs font-normal text-amber-550">indikator rawan</span>
              </h3>
            </div>
            <div className="mt-2 text-xs text-amber-800/80 leading-relaxed">
              {currentUnderperformingCount > 0
                ? `${currentUnderperformingCount} item terdeteksi memerlukan intervensi taktis pimpinan unit.`
                : `Kinerja ${dashboardFilter.toUpperCase()} luar biasa! 100% target aman dan terlampaui.`}
            </div>
            <p className="text-[10px] text-amber-600/80 mt-2">Sistem Pemantauan Unit Kerja Aktif.</p>
          </div>
        </div>
      )}

      {/* Main Analysis Section: EW Alerts (Left) & Met/On-Track Indicators (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-lists-section">
        {/* Left Side: Early Warning List Feed */}
        <div className="lg:col-span-7 bg-kemenkes-putih border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[460px]" id="underperforming-col-card">
          <div>
            <div className="p-5 border-b border-rose-100/60 bg-rose-50/20 flex items-center justify-between" id="underperforming-header">
              <div className="flex items-center gap-2.5">
                <div id="underperforming-badge-icon" className="p-2 bg-rose-100 text-rose-700 rounded-lg">
                  <ShieldAlert className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900" id="underperforming-heading">
                    Sinyal Mitigasi Kinerja ({dashboardFilter === 'all' ? 'Gabungan' : dashboardFilter.toUpperCase()})
                  </h3>
                  <p className="text-xs text-slate-500 font-sans mt-0.5">Daftar item progres yang belum menyentuh target pimpinan</p>
                </div>
              </div>
              <span className="px-2.5 py-1 text-[11px] font-mono font-extrabold bg-rose-50 border border-rose-200 text-rose-600 rounded-full" id="underperforming-qty-badge">
                {currentUnderperformingCount} Rawan
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-[380px] overflow-y-auto" id="underperforming-scroll-area">
              {currentUnderperformingCount === 0 ? (
                <div className="py-24 text-center text-slate-500 flex flex-col items-center justify-center gap-2" id="underperforming-empty-state">
                  <CheckCircle2 className="w-10 h-10 text-kemenkes-toska-dark" />
                  <p className="font-bold text-sm text-slate-800">Kerja Hebat! Sasaran Aman</p>
                  <p className="text-xs text-slate-500">Rasio pencapaian program untuk kategori ini sudah 100%.</p>
                </div>
              ) : (
                currentUnderperformingItems.map((item) => (
                  <div key={item.id} className="p-4 hover:bg-slate-50/70 transition-colors flex justify-between items-start gap-4" id={`wp-row-${item.code}`}>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded ${
                          item.type === 'IKU' 
                            ? 'bg-kemenkes-toska-light text-kemenkes-toska-dark border border-kemenkes-toska/20' 
                            : 'bg-kemenkes-kuning-light text-kemenkes-kuning-deep border border-kemenkes-kuning-dark/20'
                        }`}>
                          {item.code}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">{item.pjCode} • {item.pjDetail}</span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-800 mt-1 lines-clamp-2">
                        {item.name}
                      </h4>
                      {item.subName && (
                        <p className="text-[10px] text-slate-500 italic mt-0.5">{item.subName}</p>
                      )}
                      
                      {/* Hambatan Detail */}
                      <div className="p-2.5 bg-amber-50/60 rounded-lg border border-amber-200/40 mt-2 text-xs text-slate-700">
                        <p className="text-[10.5px] leading-relaxed">
                          <span className="font-bold text-amber-800">Kendala lapangan: </span>
                          {item.kendala || 'Belum diisikan oleh unit penanggung jawab.'}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0 flex flex-col items-end gap-1" id={`wp-right-data-${item.code}`}>
                      <p className="text-[9px] text-slate-400 font-mono tracking-wider">TARGET</p>
                      <p className="text-xs font-semibold text-slate-700 font-mono">{item.targetYearly}</p>
                      <span className="inline-block py-0.5 px-2 bg-rose-50 text-rose-600 text-[10px] font-extrabold rounded-md border border-rose-150">
                        Capaian: {item.realisation.tw1 || '0%'}
                      </span>
                      <button
                        onClick={() => onFocusIndicator(item.code)}
                        className="mt-2.5 inline-flex items-center gap-1 py-1 px-2.5 border border-slate-200 hover:border-kemenkes-toska hover:bg-kemenkes-toska-light text-slate-600 hover:text-kemenkes-toska-dark rounded-md text-[10px] font-bold transition-all cursor-pointer"
                        id={`focus-btn-${item.code}`}
                      >
                        Detail <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50 text-center text-xs" id="underperforming-footer">
            <p className="text-slate-500">
              Gunakan akun unit kerja terkait untuk memperbarui perolehan target & menyampaikan perbaikan evaluasi.
            </p>
          </div>
        </div>

        {/* Right Side: On Track / Met Indicators List */}
        <div className="lg:col-span-5 bg-kemenkes-putih border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[460px]" id="met-col-card">
          <div>
            <div className="p-5 border-b border-kemenkes-toska/20 bg-kemenkes-toska-light/40 flex items-center justify-between" id="met-header">
              <div className="flex items-center gap-2.5">
                <div id="met-badge-icon" className="p-2 bg-kemenkes-toska-light text-kemenkes-toska-dark rounded-lg">
                  <CheckCircle2 className="w-4.5 h-4.5 text-kemenkes-toska" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900" id="met-heading">
                    Indikator Sukses & On Track
                  </h3>
                  <p className="text-xs text-slate-500 font-sans mt-0.5">Daftar item progres yang telah memenuhi/melampaui sasaran</p>
                </div>
              </div>
              <span className="px-2.5 py-1 text-[11px] font-mono font-extrabold bg-kemenkes-toska-light border border-kemenkes-toska/20 text-kemenkes-toska-dark rounded-full" id="met-qty-badge">
                {currentMetCount} Sukses
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-[380px] overflow-y-auto" id="met-scroll-area">
              {currentMetCount === 0 ? (
                <div className="py-24 text-center text-slate-500 flex flex-col items-center justify-center gap-2" id="met-empty-state">
                  <AlertTriangle className="w-10 h-10 text-amber-500" />
                  <p className="font-bold text-sm text-slate-800 font-sans">Belum Ada Sasaran Terpenuhi</p>
                  <p className="text-xs text-slate-500 max-w-xs px-4">
                    Seluruh program di kategori ini belum mencapai treshold target minimum triwulanan.
                  </p>
                </div>
              ) : (
                currentMetItems.map((item) => (
                  <div key={item.id} className="p-4 hover:bg-slate-50/70 transition-colors flex justify-between items-start gap-3" id={`met-row-${item.code}`}>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded ${
                          item.type === 'IKU' 
                            ? 'bg-kemenkes-toska-light text-kemenkes-toska-dark border border-kemenkes-toska/20' 
                            : 'bg-kemenkes-kuning-light text-kemenkes-kuning-deep border border-kemenkes-kuning-dark/20'
                        }`}>
                          {item.code}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 truncate">{item.pjCode}</span>
                      </div>
                      <h4 className="text-xs font-semibold text-slate-700 mt-1 truncate">
                        {item.name}
                      </h4>
                      {item.subName && (
                        <p className="text-[10px] text-slate-500 italic truncate mt-0.5">{item.subName}</p>
                      )}
                    </div>

                    <div className="text-right shrink-0 flex flex-col items-end gap-1" id={`met-right-data-${item.code}`}>
                      <p className="text-[9px] text-slate-400 font-mono">TARGET</p>
                      <p className="text-xs font-bold text-slate-900 font-mono">{item.targetYearly}</p>
                      <span className="inline-block py-0.5 px-2 bg-kemenkes-toska-light text-kemenkes-toska-dark text-[10px] font-bold rounded-md border border-kemenkes-toska/15">
                        Capaian: {item.realisation.tw1}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50 text-center text-xs" id="met-footer">
            <p className="text-[#0db9ac] font-medium">
              Sistem mencatat komitmen mutu yang luar biasa pada target di atas!
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
