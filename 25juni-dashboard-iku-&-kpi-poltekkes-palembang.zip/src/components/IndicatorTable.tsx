import { useState } from 'react';
import { Achievement, IndicatorType, MonthlyTrend } from '../types';
import { 
  Search, 
  ExternalLink, 
  Download, 
  AlertTriangle, 
  CheckCircle2, 
  Filter,
  Users,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  TrendingUp,
  ChevronDown,
  Info
} from 'lucide-react';

interface IndicatorTableProps {
  achievements: Achievement[];
  selectedIndicatorId: string | null;
  onSelectIndicator: (id: string | null) => void;
  currentUser: any;
}

export default function IndicatorTable({
  achievements,
  selectedIndicatorId,
  onSelectIndicator,
}: IndicatorTableProps) {
  const [search, setSearch] = useState('');
  const [indicatorTypeFilter, setIndicatorTypeFilter] = useState<'all' | 'IKU' | 'KPI'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'met' | 'under'>('all');
  const [pjFilter, setPjFilter] = useState<'all' | 'Wadir 1' | 'Wadir 2' | 'Wadir 3' | 'SPI'>('all');

  // Find active selected indicator for trend charting
  const selectedIndicator = achievements.find(a => a.id === selectedIndicatorId) || achievements[0];

  const checkIsMet = (item: Achievement) => {
    const val = item.realValues.tw1;
    if (val === null) return false;
    return val >= item.targetNum;
  };

  // Filter computation
  const filteredAchievements = achievements.filter((item) => {
    // Search match
    const matchesSearch = 
      item.name.toLowerCase().includes(search.toLowerCase()) || 
      (item.subName && item.subName.toLowerCase().includes(search.toLowerCase())) ||
      item.code.toLowerCase().includes(search.toLowerCase()) ||
      item.pjDetail.toLowerCase().includes(search.toLowerCase());

    // Type match
    const matchesType = indicatorTypeFilter === 'all' || item.type === indicatorTypeFilter;

    // Status match
    const isMet = checkIsMet(item);
    const matchesStatus = 
      statusFilter === 'all' || 
      (statusFilter === 'met' && isMet) || 
      (statusFilter === 'under' && !isMet);

    // PJ match
    const matchesPj = pjFilter === 'all' || item.pjCode === pjFilter;

    return matchesSearch && matchesType && matchesStatus && matchesPj;
  });

  // Highlight selected indicator's monthly trend in interactive SVG Chart
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // Custom interactive SVG line chart render for monthly trend monitoring
  const renderTrendChart = (indicator: Achievement) => {
    if (!indicator) return null;

    const values = months.map(m => indicator.monthlyTrend[m] || 0);
    const maxVal = Math.max(...values, indicator.targetNum * 1.1, 10) || 100;
    
    // SVG Dimensions
    const width = 800;
    const height = 180;
    const paddingLeft = 50;
    const paddingRight = 20;
    const paddingTop = 20;
    const paddingBottom = 30;

    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    // Mapping coordinates
    const points = months.map((m, idx) => {
      const x = paddingLeft + (idx / (months.length - 1)) * chartWidth;
      const yStr = indicator.monthlyTrend[m];
      const val = yStr !== null && yStr !== undefined ? Number(yStr) : null;
      
      if (val === null) return null;
      const y = paddingTop + chartHeight - (val / maxVal) * chartHeight;
      return { x, y, month: m, val };
    });

    const validPoints = points.filter(p => p !== null) as { x: number; y: number; month: string; val: number }[];
    const pathD = validPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

    // Target Line calculation
    const targetY = paddingTop + chartHeight - (indicator.targetNum / maxVal) * chartHeight;

    return (
      <div className="bg-slate-900 border border-slate-800 text-white p-5 rounded-2xl shadow-inner relative">
        <div className="flex justify-between items-start mb-4">
          <div>
            <span className="text-[10px] font-mono uppercase bg-kemenkes-toska/10 text-kemenkes-toska border border-kemenkes-toska/30 px-2 py-0.5 rounded">
              Trend Pemantauan Bulanan (Real-Time)
            </span>
            <h4 className="text-sm font-bold text-slate-100 mt-1 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-kemenkes-kuning-dark" />
              {indicator.code}: {indicator.name}
            </h4>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Target Tahunan: <span className="text-white font-semibold font-mono">{indicator.targetYearly}</span> • Unit: <span className="capitalize text-kemenkes-toska font-mono text-[10.5px]">{indicator.unit}</span>
            </p>
          </div>
          <div className="text-right shrink-0 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/50">
            <span className="text-[9px] font-mono text-slate-500 block">REALISASI TW I</span>
            <span className="text-sm font-bold font-mono text-kemenkes-toska">{indicator.realisation.tw1 || '0%'}</span>
          </div>
        </div>

        {validPoints.length === 0 ? (
          <div className="h-32 flex items-center justify-center text-slate-500 text-xs">
            Belum ada entri progres bulanan untuk indikator ini.
          </div>
        ) : (
          <div className="relative overflow-x-auto">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto min-w-[600px]">
              {/* Grid Lines */}
              <line x1={paddingLeft} y1={paddingTop} x2={width - paddingRight} y2={paddingTop} stroke="#1e293b" strokeDasharray="3,3" />
              <line x1={paddingLeft} y1={paddingTop + chartHeight / 2} x2={width - paddingRight} y2={paddingTop + chartHeight / 2} stroke="#1e293b" strokeDasharray="3,3" />
              <line x1={paddingLeft} y1={paddingTop + chartHeight} x2={width - paddingRight} y2={paddingTop + chartHeight} stroke="#334155" />

              {/* Grid vertical lines for months */}
              {months.map((m, idx) => {
                const x = paddingLeft + (idx / (months.length - 1)) * chartWidth;
                return (
                  <line key={m} x1={x} y1={paddingTop} x2={x} y2={paddingTop + chartHeight} stroke="#1e293b" strokeWidth={0.5} />
                );
              })}

              {/* Target Line */}
              {targetY >= paddingTop && targetY <= paddingTop + chartHeight && (
                <g>
                  <line 
                    x1={paddingLeft} 
                    y1={targetY} 
                    x2={width - paddingRight} 
                    y2={targetY} 
                    stroke="#ef4444" 
                    strokeWidth={1.5} 
                    strokeDasharray="4,4" 
                  />
                  <text 
                    x={width - paddingRight - 80} 
                    y={targetY - 5} 
                    fill="#ef4444" 
                    className="text-[10px] font-mono font-bold"
                  >
                    TARGET: {indicator.targetYearly}
                  </text>
                </g>
              )}

              {/* Trend Path */}
              <path 
                d={pathD} 
                fill="none" 
                stroke="#0db9ac" 
                strokeWidth={3} 
                strokeLinecap="round" 
                strokeLinejoin="round" 
              />

              {/* Area under curve */}
              {validPoints.length > 0 && (
                <path
                  d={`${pathD} L ${validPoints[validPoints.length - 1].x} ${paddingTop + chartHeight} L ${validPoints[0].x} ${paddingTop + chartHeight} Z`}
                  fill="url(#grad2)"
                />
              )}

              {/* Data Dots & Tooltips */}
              {validPoints.map((p) => (
                <g key={p.month}>
                  <circle 
                    cx={p.x} 
                    cy={p.y} 
                    r={5} 
                    fill="#0db9ac" 
                    stroke="#020617" 
                    strokeWidth={2} 
                  />
                  {/* Tooltip text anchor */}
                  <text 
                    x={p.x} 
                    y={p.y - 12} 
                    fill="#fff" 
                    textAnchor="middle" 
                    className="text-[10px] font-semibold font-mono"
                  >
                    {p.val}
                  </text>
                </g>
              ))}

              {/* Month Labels */}
              {months.map((m, idx) => {
                const x = paddingLeft + (idx / (months.length - 1)) * chartWidth;
                const isReported = indicator.monthlyTrend[m] !== null;
                return (
                  <text 
                    key={m} 
                    x={x} 
                    y={paddingTop + chartHeight + 18} 
                    fill={isReported ? "#0db9ac" : "#475569"} 
                    textAnchor="middle" 
                    className="text-[10px] font-mono font-bold"
                  >
                    {m}
                  </text>
                );
              })}

              {/* Y Axis Legend labels */}
              <text x={10} y={paddingTop + 6} fill="#475569" className="text-[9px] font-mono">MAX: {Math.round(maxVal)}</text>
              <text x={10} y={paddingTop + chartHeight} fill="#475569" className="text-[9px] font-mono">0</text>

              {/* SVG Gradients definitions */}
              <defs>
                <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#0db9ac" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#0db9ac" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-6">
      
      {/* 1. Main Interactive Comparison Trend Line chart */}
      {selectedIndicator && renderTrendChart(selectedIndicator)}

      {/* 2. Filters & Searches Section */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
        {/* Search Field */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari indikator, kode, atau unit kerja penanggung jawab..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska outline-none transition-all placeholder:text-slate-400"
          />
        </div>

        {/* Filters Group */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Filter Type */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs">
            <Layers className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={indicatorTypeFilter}
              onChange={(e) => setIndicatorTypeFilter(e.target.value as any)}
              className="bg-transparent border-none outline-none font-semibold text-slate-700 cursor-pointer pr-1"
            >
              <option value="all">Semua Tipe (IKU & KPI)</option>
              <option value="IKU">IKU Poltekkes</option>
              <option value="KPI">KPI Ketua BLU</option>
            </select>
          </div>

          {/* Filter Status */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-transparent border-none outline-none font-semibold text-slate-700 cursor-pointer pr-1"
            >
              <option value="all">Semua Status</option>
              <option value="met">Tercapai (≥ Target)</option>
              <option value="under">Belum Tercapai (Di Bawah)</option>
            </select>
          </div>

          {/* Filter PJ Unit */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs">
            <Users className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={pjFilter}
              onChange={(e) => setPjFilter(e.target.value as any)}
              className="bg-transparent border-none outline-none font-semibold text-slate-700 cursor-pointer pr-1"
            >
              <option value="all">Semua Penanggung Jawab</option>
              <option value="Wadir 1">Wadir I (Akademik)</option>
              <option value="Wadir 2">Wadir II (KU/Kepeg.)</option>
              <option value="Wadir 3">Wadir III (Alumni/Mhs)</option>
              <option value="SPI">SPI (Pengawasan)</option>
            </select>
          </div>
        </div>
      </div>

      {/* 3. Indicators Grid/Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
          <span className="text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
            DAFTAR INDIKATOR TERBENTUK ({filteredAchievements.length} item)
          </span>
          <span className="text-[11px] text-slate-400 italic">
            💡 Klik baris tabel untuk menampilkan tren bulanan interaktif di atas!
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 text-[10px] font-mono uppercase bg-slate-50/40">
                <th className="py-3 px-4 text-center w-16">Tipe</th>
                <th className="py-3 px-4 w-20">Kode</th>
                <th className="py-3 px-4">Deskripsi Capaian Indikator</th>
                <th className="py-3 px-4 text-center w-28">Target Tahunan</th>
                <th className="py-3 px-4 text-center w-28">Realisasi TW I</th>
                <th className="py-3 px-4 text-center w-24">Status</th>
                <th className="py-3 px-4 text-center w-24">Log Dukung</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredAchievements.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 font-sans">
                    Tidak ditemukan indikator yang sesuai dengan kriteria filter Anda. Let's reset filters.
                  </td>
                </tr>
              ) : (
                filteredAchievements.map((item) => {
                  const isMet = checkIsMet(item);
                  const isSelected = selectedIndicatorId === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => onSelectIndicator(item.id)}
                      className={`hover:bg-slate-50/80 transition-all cursor-pointer border-l-4 ${
                        isSelected 
                          ? 'bg-kemenkes-toska-light/40 border-l-kemenkes-toska font-bold' 
                          : 'border-l-transparent'
                      }`}
                    >
                      {/* Tipe Badge */}
                      <td className="py-4 px-4 text-center">
                        <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          item.type === 'IKU' 
                            ? 'bg-kemenkes-toska-light text-kemenkes-toska-dark border border-kemenkes-toska/20' 
                            : 'bg-kemenkes-kuning-light text-kemenkes-kuning-deep border border-kemenkes-kuning-dark/20'
                        }`}>
                          {item.type}
                        </span>
                      </td>

                      {/* Kode */}
                      <td className="py-4 px-4 font-mono font-bold text-slate-700">{item.code}</td>

                      {/* Deskripsi */}
                      <td className="py-4 px-4 max-w-md">
                        <h5 className="font-semibold text-slate-900 leading-tight">
                          {item.name}
                        </h5>
                        {item.subName && (
                          <p className="text-[10.5px] text-slate-500 mt-1">{item.subName}</p>
                        )}
                        <p className="text-[10px] text-slate-400 font-mono mt-1.5 flex items-center gap-1">
                          <Users className="w-3 h-3 text-slate-400" />
                          PJ: <span className="text-slate-500 font-semibold">{item.pjCode} • {item.pjDetail}</span>
                        </p>
                        {!isMet && (item.justification || item.kendala) && (
                          <div className="mt-2.5 p-2 bg-amber-50/50 rounded-lg text-[10.5px] border border-amber-100/60 leading-normal flex items-start gap-1.5">
                            <Info className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                            <div>
                              {item.kendala && <p className="text-amber-800"><span className="font-bold">Hambatan:</span> {item.kendala}</p>}
                              {item.justification && <p className="text-slate-600 mt-0.5"><span className="font-bold">Rincian:</span> {item.justification}</p>}
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Target */}
                      <td className="py-4 px-4 text-center font-mono font-bold text-slate-800 bg-slate-50/10">
                        {item.targetYearly}
                      </td>

                      {/* Realisasi */}
                      <td className="py-4 px-4 text-center font-mono font-bold text-slate-900 bg-slate-50/20">
                        {item.realisation.tw1 || '-'}
                      </td>

                      {/* Status Check badge */}
                      <td className="py-4 px-4 text-center">
                        {isMet ? (
                          <span className="inline-flex items-center gap-1 bg-kemenkes-toska-light text-kemenkes-toska-dark font-extrabold px-2.5 py-1 rounded-full text-[10px] border border-kemenkes-toska/30">
                            <CheckCircle2 className="w-3 h-3 text-kemenkes-toska-dark" />
                            Met
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-600 font-bold px-2.5 py-1 rounded-full text-[10px] border border-rose-200">
                            <AlertTriangle className="w-3 h-3 text-rose-500" />
                            Kurang
                          </span>
                        )}
                      </td>

                      {/* Support Document Link */}
                      <td className="py-4 px-4 text-center">
                        {item.supportLink && item.supportLink !== '-' ? (
                          <a
                            href={item.supportLink}
                            target="_blank"
                            referrerPolicy="no-referrer"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="inline-flex items-center gap-1.5 py-1.5 px-2.5 bg-kemenkes-toska hover:bg-kemenkes-toska-hover text-slate-950 rounded-lg font-bold transition-all text-[11px] shadow-sm cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            Dukung
                          </a>
                        ) : (
                          <span className="text-slate-400 font-mono text-[10px] italic">Tidak ada</span>
                        )}
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
