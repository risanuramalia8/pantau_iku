/**
 * TYPES FOR POLTEKKES PALEMBANG IKU/KPI DASHBOARD
 */

export type IndicatorType = 'IKU' | 'KPI';

export interface PerformanceTarget {
  tw1: number | string | null;
  tw2: number | string | null;
  tw3: number | string | null;
  tw4: number | string | null;
}

export interface MonthlyTrend {
  [month: string]: number | null; // Value for each month (e.g. "Jan", "Feb", etc.)
}

export interface Achievement {
  id: string;
  type: IndicatorType;
  no: string;          // Original indicator number (e.g., "1", "2")
  code: string;        // Combination (e.g., "IKU-1" or "KPI-5")
  name: string;        // Primary indicator name
  subName?: string;    // Sub performance indicator name (especially for KPI)
  unit: string;        // e.g. "persen", "rupiah", "indeks", "nilai"
  targetYearly: string; // The baseline target for the year (e.g. "66.02%", "Rp 60.85B")
  targetNum: number;   // Normalized numerical target for percentage/numerical computations
  weight?: string;     // Bobot
  pjCode: string;      // PJ Unit code (e.g. "Wadir 1", "Wadir 2", "Wadir 3", "SPI")
  pjDetail: string;    // Division detail (e.g. "Akademik", "Keuangan", "Kepegawaian")
  
  // Quarterly Realization
  realisation: {
    tw1: string | null;
    tw2: string | null;
    tw3: string | null;
    tw4: string | null;
  };
  
  // Numerical values of quarterly achievements for chart plotting
  realValues: {
    tw1: number | null;
    tw2: number | null;
    tw3: number | null;
    tw4: number | null;
  };

  // Monthly breakdown trends
  monthlyTrend: MonthlyTrend;

  // Support context
  supportLink: string;      // Url data dukung
  justification: string;    // Penjelasan Capaian jika belum tercapai
  kendala: string;          // Kendala/Hambatan
  lastUpdated: string;      // ISO String date
  updatedBy?: string;
}

export interface UserSession {
  username: string;
  role: 'admin' | 'unit';
  pjCode: string; // 'all', 'Wadir 1', 'Wadir 2', 'Wadir 3', 'SPI'
  token?: string;
}

export interface DashboardSummary {
  totalIKUCount: number;
  totalKPICount: number;
  ikuAchievedCount: number;
  kpiAchievedCount: number;
  averageProgressIKU: number;
  averageProgressKPI: number;
}
