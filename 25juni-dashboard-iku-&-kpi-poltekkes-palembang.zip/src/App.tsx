import { useState, useEffect, FormEvent } from 'react';
import { Achievement, UserSession } from './types';
import Sidebar from './components/Sidebar';
import DashboardOverview from './components/DashboardOverview';
import IndicatorTable from './components/IndicatorTable';
import AdminPanel from './components/AdminPanel';
import PDFReportGenerator from './components/PDFReportGenerator';
import { 
  LogIn, 
  X, 
  Database,
  ShieldCheck, 
  TrendingUp, 
  AlertTriangle,
  Lightbulb,
  Building,
  Key,
  EyeOff,
  Eye,
  Activity,
  Menu
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isSidebarVisible, setIsSidebarVisible] = useState(false);

  // Login form states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Fetch achievements of Poltekkes
  const fetchAchievements = async () => {
    try {
      const res = await fetch('/api/achievements');
      const data = await res.json();
      if (Array.isArray(data)) {
        setAchievements(data);
        if (data.length > 0 && !selectedId) {
          setSelectedId(data[0].id);
        }
      }
    } catch (err) {
      console.error('Failed to load achievements from database:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAchievements();
  }, []);

  // Update Capaian / target handler
  const handleUpdateIndicator = async (id: string, updatedFields: Partial<Achievement>): Promise<boolean> => {
    if (!currentUser) return false;
    try {
      const res = await fetch(`/api/achievements/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'auth-user': currentUser.username,
          'auth-pj': currentUser.pjCode,
        },
        body: JSON.stringify(updatedFields),
      });
      if (res.ok) {
        await fetchAchievements();
        return true;
      }
    } catch (err) {
      console.error('Update indicator failed:', err);
    }
    return false;
  };

  // Secure Auth Login action
  const handleLoginSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (res.ok) {
        setCurrentUser(data);
        setShowLoginModal(false);
        // Clear login fields
        setUsername('');
        setPassword('');
        // Toggle to input view to assist unit right away
        setActiveTab('input');
      } else {
        setLoginError(data.error || 'Autentikasi gagal.');
      }
    } catch (err) {
      setLoginError('Koneksi terputus. Gagal melapor ke server.');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    if (activeTab === 'input') {
      setActiveTab('dashboard');
    }
  };

  return (
    <div className="flex bg-slate-50 min-h-screen text-slate-800">
      
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        onLoginClick={() => setShowLoginModal(true)}
        isVisible={isSidebarVisible}
        onToggleVisibility={setIsSidebarVisible}
      />

      {/* Main Content Area */}
      <main className="flex-1 p-8 overflow-y-auto max-w-7xl mx-auto flex flex-col gap-6">
        
        {/* Dynamic header row with PDF generator */}
        <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-5">
          <div className="flex items-center gap-4.5">
            {!isSidebarVisible && (
              <button
                id="sidebar-expand-btn"
                onClick={() => setIsSidebarVisible(true)}
                className="flex items-center gap-2 p-2.5 px-4 bg-slate-900 text-white hover:bg-slate-800 rounded-xl text-xs font-bold shadow-md shadow-slate-950/15 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0 border border-slate-800"
                title="Tampilkan Menu"
              >
                <Menu className="w-4 h-4 text-kemenkes-toska" />
                <span>Menu</span>
              </button>
            )}
            <div>
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4 text-kemenkes-toska" />
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-bold">POLTEKKES KEMENKES PALEMBANG</span>
              </div>
              <h1 className="text-xl font-extrabold text-slate-900 mt-1 leading-tight tracking-tight">
                Sistem Penjaminan Mutu & Pengendalian Target Kerja (Monev)
              </h1>
            </div>
          </div>
          
          {/* Automatic Report PDF Download Trigger */}
          {achievements.length > 0 && (
            <div className="shrink-0">
              <PDFReportGenerator achievements={achievements} />
            </div>
          )}
        </header>

        {loading ? (
          <div className="flex-1 py-40 flex flex-col items-center justify-center gap-3">
            <div className="w-10 h-10 border-4 border-kemenkes-toska/20 border-t-kemenkes-toska rounded-full animate-spin"></div>
            <p className="font-mono text-xs text-slate-400">MEMUAT DATABASE KINERJA...</p>
          </div>
        ) : (
          <div className="flex-1 flex flex-col gap-6">
            
            {/* View Switching */}
            {activeTab === 'dashboard' && (
              <DashboardOverview 
                achievements={achievements} 
                onFocusIndicator={(code) => {
                  const target = achievements.find(a => a.code === code);
                  if (target) {
                    setSelectedId(target.id);
                    setActiveTab('indicators');
                  }
                }}
              />
            )}

            {activeTab === 'indicators' && (
              <IndicatorTable
                achievements={achievements}
                selectedIndicatorId={selectedId}
                onSelectIndicator={setSelectedId}
                currentUser={currentUser}
              />
            )}

            {activeTab === 'input' && currentUser && (
              <AdminPanel
                achievements={achievements}
                currentUser={currentUser}
                onUpdateIndicator={handleUpdateIndicator}
              />
            )}

          </div>
        )}

      </main>

      {/* 4. MODAL LOGIN DIALOG */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-100 overflow-hidden relative">
            
            {/* Header */}
            <div className="p-6 pb-4 border-b border-slate-100 bg-slate-50 relative">
              <button
                onClick={() => setShowLoginModal(false)}
                className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded-full hover:bg-slate-200/50"
              >
                <X className="w-4.5 h-4.5" />
              </button>
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-kemenkes-toska-light text-kemenkes-toska-dark rounded-xl">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Masuk Sistem Monev</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Masuk menggunakan kredensial unit atau admin</p>
                </div>
              </div>
            </div>

            {/* Login Account Form */}
            <form onSubmit={handleLoginSubmit} className="p-6 flex flex-col gap-4">
              
              {loginError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800 font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  {loginError}
                </div>
              )}

              {/* Username */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Username Akun</label>
                <input
                  type="text"
                  placeholder="Misal: wadir1 atau wadir2 atau admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                  required
                />
              </div>

              {/* Password */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Kata Sandi (Password)</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Masukkan sandi unit Anda"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:ring-2 focus:ring-kemenkes-toska/20 focus:border-kemenkes-toska"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer text-xs"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Account Hints Block */}
              <div className="p-3 bg-kemenkes-toska-light/50 rounded-xl border border-kemenkes-toska/15 flex flex-col gap-1.5 text-[10.5px] text-slate-500">
                <p className="font-bold text-[11px] text-kemenkes-toska-dark flex items-center gap-1">
                  <Lightbulb className="w-3.5 h-3.5 text-kemenkes-toska" /> Akun Demo Unit Kerja / Admin:
                </p>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 font-mono text-slate-600">
                  <span>• admin / admin123</span>
                  <span>• wadir1 / wadir1123</span>
                  <span>• wadir2 / wadir2123</span>
                  <span>• wadir3 / wadir3123</span>
                  <span>• spi / spi123</span>
                </div>
              </div>

              <button
                type="submit"
                className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-kemenkes-toska hover:bg-kemenkes-toska-hover text-slate-950 rounded-xl font-bold font-sans text-xs shadow-lg shadow-kemenkes-toska/15 cursor-pointer transition-all active:scale-[0.98]"
              >
                <LogIn className="w-3.5 h-3.5" />
                Masuk Sistem
              </button>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
