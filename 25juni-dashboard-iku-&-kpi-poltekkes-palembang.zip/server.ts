import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { Achievement, IndicatorType, MonthlyTrend } from './src/types';

const app = express();
app.use(express.json());

const PORT = 3000;
const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'db.json');

// Initialize Gemini SDK with telemetry header requested in SKILL.md
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Mock login database
const USERS = [
  { username: 'admin', password: 'admin123', pjCode: 'all', role: 'admin' },
  { username: 'wadir1', password: 'wadir1123', pjCode: 'Wadir 1', role: 'unit' },
  { username: 'wadir2', password: 'wadir2123', pjCode: 'Wadir 2', role: 'unit' },
  { username: 'wadir3', password: 'wadir3123', pjCode: 'Wadir 3', role: 'unit' },
  { username: 'spi', password: 'spi123', pjCode: 'SPI', role: 'unit' },
];

// Seed raw IKU data
const SEED_IKU = [
  {
    no: '1',
    name: 'IKM 17.3.1 - Persentase Serapan Lulusan General (≤6 Bulan dari Tanggal Ijazah)',
    unit: 'persen',
    targetYearly: '66,02%',
    targetNum: 66.02,
    tw1: '66,02%',
    supportLink: 'https://docs.google.com/spreadsheets/d/1OByyD9curmVJNmDSXL-qassOMtkMcfxc/edit?usp=sharing',
    justification: 'Proses Pengisian (prodi D3 Kesgi dan D3 Farmasi 100%) prodi lainnya belum semuanya',
    kendala: '-',
    pjCode: 'Wadir 3',
    pjDetail: 'Alumni dan Kerjasama',
  },
  {
    no: '2',
    name: 'IKM 17.3.2 - Persentase Serapan Lulusan yang Bekerja di Sektor Kesehatan',
    unit: 'persen',
    targetYearly: '83%',
    targetNum: 83,
    tw1: '43,08%',
    supportLink: 'https://docs.google.com/spreadsheets/d/1OByyD9curmVJNmDSXL-qassOMtkMcfxc/edit?usp=sharing',
    justification: 'Proses Pengisian (prodi D3 Kesgi dan D3 Farmasi 100%) prodi lainnya belum semuanya',
    kendala: 'Keterlambatan pengumpulan kuesioner dari alumni prodi keperawatan.',
    pjCode: 'Wadir 3',
    pjDetail: 'Alumni dan Kerjasama',
  },
  {
    no: '3',
    name: 'IKM 17.3.3 - Persentase Serapan Lulusan LN',
    unit: 'persen',
    targetYearly: '46,15%',
    targetNum: 46.15,
    tw1: '0%',
    supportLink: 'https://docs.google.com/spreadsheets/d/1OByyD9curmVJNmDSXL-qassOMtkMcfxc/edit?usp=sharing',
    justification: 'Proses pengisian masih minim pendaftar alumni untuk skema luar negeri.',
    kendala: 'Hambatan bahasa dan pengurusan visa kerja di luar negeri.',
    pjCode: 'Wadir 3',
    pjDetail: 'Alumni dan Kerjasama',
  },
  {
    no: '4',
    name: 'IKM 17.3.4 - Persentase Kelulusan Uji Kompetensi (Ukom)',
    unit: 'persen',
    targetYearly: '96,77%',
    targetNum: 96.77,
    tw1: '0%',
    supportLink: 'https://drive.google.com/drive/folders/1ySUxkC1qAlO74h3XaM3GsAzmETZpLaRE',
    justification: 'Belum ada yang mengikuti Ukom pada TW 1; belum ada yg ikut ukom first taker karena masih proses PBM semester VI dan penyelesaian LTA.',
    kendala: 'Penyelesaian LTA mahasiswa masih berlangsung.',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '5',
    name: 'IKM 17.3.5 - Jumlah Penelitian yang Dipublikasikan',
    unit: 'nilai',
    targetYearly: '48 Penelitian',
    targetNum: 48,
    tw1: '14',
    supportLink: 'https://docs.google.com/spreadsheets/d/18nqLg6xSOVKEyA0IKzRwj8NqJ4YwnMxz/edit',
    justification: 'Saat ini baru pencairan dana penelitian tahap 1 dari 5 tahapan; dosen baru melakukan penelitian.',
    kendala: 'Administrasi penelitian dan review proposal di awal tahun anggaran.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '6',
    name: 'IKM 17.3.6 - Jumlah Produk Inovasi yang Dihasilkan dan/atau Dikomersialisasikan',
    unit: 'nilai',
    targetYearly: '19 Inovasi',
    targetNum: 19,
    tw1: '0',
    supportLink: '-',
    justification: 'Penelitian dan pengmas penghasil inovasi belum selesai dilaksanakan.',
    kendala: 'Tahapan riset inovatif membutuhkan waktu minimal 2 triwulan.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '7',
    name: 'IKM 17.3.7 - Jumlah Pengabdian kepada Masyarakat yang Dihasilkan',
    unit: 'nilai',
    targetYearly: '48 Pengabdian Masyarakat',
    targetNum: 48,
    tw1: '0',
    supportLink: '-',
    justification: 'Masih menunggu penambahan dana pengmas; dosen pengabdi saat ini sedang melaksanakan persiapan lokasi kegiatan.',
    kendala: 'Penyesuaian jadwal pelaksanaan dengan mitra puskesmas/desa.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '8',
    name: 'IKM 17.3.8 - Rasio Dosen Tetap terhadap Mahasiswa',
    unit: 'indeks',
    targetYearly: '1:30 Rasio',
    targetNum: 30,
    tw1: '1:30 Rasio',
    supportLink: 'https://docs.google.com/spreadsheets/d/1Vd_GcgYhleZFF8aQTJ2sqsNNbOVahd0D/edit',
    justification: 'Rasio terpenuhi sesuai ketentuan standar pendidikan kementerian.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '9',
    name: 'IKM 17.3.9 - Persentase Dosen Tetap dengan Kualifikasi Lektor Kepala dan/atau Guru Besar',
    unit: 'persen',
    targetYearly: '23,93%',
    targetNum: 23.93,
    tw1: '23.36%',
    supportLink: 'https://drive.google.com/drive/folders/1CMvMDAAzlzkZtYKYzDr6XC9F178yYCyb',
    justification: 'Sedang proses pengurusan sertifikat kompetensi (serkom) Lektor Kepala.',
    kendala: 'Keterlambatan verifikasi berkas di tingkat pusat.',
    pjCode: 'Wadir 2',
    pjDetail: 'Kepegawaian',
  },
  {
    no: '10',
    name: 'IKM 17.3.10 - Persentase Dosen Fungsional yang Memiliki Sertifikasi Dosen',
    unit: 'persen',
    targetYearly: '84,62%',
    targetNum: 84.62,
    tw1: '81,07%',
    supportLink: 'data_rekap_serdos_tahun_2026_tw_1.pdf',
    justification: 'Pelaksanaan Sertifikasi Dosen Gelombang 1 Tahun 2026 belum dibuka oleh panitia pusat.',
    kendala: 'Menunggu jadwal resmi dari Kemendikbudristek/Kemenkes.',
    pjCode: 'Wadir 1',
    pjDetail: 'UPM',
  },
  {
    no: '11',
    name: 'IKM 17.3.11 - Persentase Dosen Tetap yang Memiliki Kemampuan Berbahasa Inggris',
    unit: 'persen',
    targetYearly: '13%',
    targetNum: 13,
    tw1: '8,84%',
    supportLink: 'https://drive.google.com/drive/folders/1WvWQUVoKvqYYKgXeevdTe3Oqz4pO5ZzV',
    justification: 'Pelatihan bahasa inggris TOEFL baru terjadwal mulai Mei 2026.',
    kendala: 'Padatnya jadwal kuliah dosen menghambat pelaksanaan tes sertifikasi rutin.',
    pjCode: 'Wadir 1',
    pjDetail: 'Pengembangan Bahasa',
  },
  {
    no: '12',
    name: 'IKM 17.3.12 - Jumlah Prestasi Dosen',
    unit: 'nilai',
    targetYearly: '10 Prestasi',
    targetNum: 10,
    tw1: '2 Prestasi',
    supportLink: 'https://drive.google.com/drive/folders/1lT7Pjf-k_qiIXaBNYLJCM6ka8dQ4ehmX',
    justification: 'Capaian kinerja prestasi dosen baru terdata 2 pada TW 1; akan diteruskan pada triwulan berikutnya (On Track).',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'UPM',
  },
  {
    no: '13',
    name: 'IKM 17.3.13 - Jumlah Prestasi Mahasiswa',
    unit: 'nilai',
    targetYearly: '96 Prestasi',
    targetNum: 96,
    tw1: '48 (15 lokal, 1 regional, 32 nasional)',
    supportLink: 'http://s.kemkes.go.id/PrestasiMahasiswa_NonAkademik_2026',
    justification: 'Capaian luar biasa 48 prestasi pada TW 1; on track memenuhi target tahunan.',
    kendala: '-',
    pjCode: 'Wadir 3',
    pjDetail: 'Kemahasiswaan',
  },
  {
    no: '14',
    name: 'IKM 17.3.14 - Persentase Prodi memiliki Akreditasi Unggul atau Akreditasi Internasional',
    unit: 'persen',
    targetYearly: '70,59%',
    targetNum: 70.59,
    tw1: '64,71%',
    supportLink: 'https://pjm.poltekkespalembang.ac.id/tabel-sk-dan-sertifikat-akreditasi/',
    justification: 'Masih dalam proses persiapan reakreditasi pada 3 program studi utama.',
    kendala: 'Borang akreditasi prodi D3 sanitasi sedang tahap unggah.',
    pjCode: 'Wadir 1',
    pjDetail: 'UPM',
  },
  {
    no: '15',
    name: 'IKM 33.1.1 - Nilai SAKIP Satuan Kerja',
    unit: 'nilai',
    targetYearly: '83 Nilai',
    targetNum: 83,
    tw1: '85,50',
    supportLink: 'https://drive.google.com/drive/folders/12GWdO0v8YwQ3IaLJ5Ay7d9yHFOfzW5u1',
    justification: 'Penilaian Mandiri SAKIP Tahun 2025 oleh SPI berdasarkan surat tugas direktur.',
    kendala: '-',
    pjCode: 'SPI',
    pjDetail: 'SPI',
  },
  {
    no: '16',
    name: 'IKM 33.2.1 - Nilai Kinerja Anggaran Satuan Kerja',
    unit: 'nilai',
    targetYearly: '92,75 Nilai',
    targetNum: 92.75,
    tw1: '0',
    supportLink: 'monev_kemenkeu_tw1.png',
    justification: 'Monitoring NKA tahun 2026 pada website monev kemenkeu baru diupdate akhir semester.',
    kendala: 'Sistem Kemenkeu belum memunculkan nilai akumulasi triwulan pertama.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '17',
    name: 'IKM 33.2.2 - Persentase EBITDA Margin',
    unit: 'persen',
    targetYearly: '20,36%',
    targetNum: 20.36,
    tw1: '55,52%',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1um_qPMbtzGBQbwxZ_gF_bSdzhPS7jpEv',
    justification: 'Capaian EBITDA margin sangat tinggi karena optimalisasi efisiensi biaya operasional awal tahun.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '18',
    name: 'IKM 33.2.3 - Jumlah Pendapatan Badan Layanan Umum',
    unit: 'rupiah',
    targetYearly: 'Rp 60.859.000.000',
    targetNum: 60859000000,
    tw1: 'Rp 26.196.858.920',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1nNPcO8EfFiYCyHL02DSQIkapO_UgRzaz',
    justification: 'Pengumpulan SPP semester genap berjalan lancar.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '19',
    name: 'IKM 33.2.4 - Jumlah Pendapatan BLU dari Optimalisasi Aset dan Kerja Sama',
    unit: 'rupiah',
    targetYearly: 'Rp 10.751.317.000',
    targetNum: 10751317000,
    tw1: 'Rp 766.990.000',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1gWq-ovmw2TALO_5v5yxNb_WY7fqjZmfz',
    justification: 'Sewa kantin, gedung serbaguna, dan klinik berjalan di awal triwulan.',
    kendala: 'Bebrapa kemitraan kerja sama swasta baru aktif kontrak di Triwulan II.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '20',
    name: 'IKM 33.3.1 - Indeks Kualitas SDM Satuan Kerja',
    unit: 'nilai',
    targetYearly: '84 Nilai',
    targetNum: 84,
    tw1: '81,15',
    supportLink: 'https://drive.google.com/file/d/10NkiBkCJR_O1WdGIE76kl7BNqQIo9fBw',
    justification: 'Perlu peningkatan pelatihan fungsional administrasi bagi staf.',
    kendala: 'Keterbatasan kuota diklat teknis kepegawaian tahun 2026.',
    pjCode: 'Wadir 2',
    pjDetail: 'Kepegawaian',
  },
  {
    no: '21',
    name: 'IKM 33.4.1 - Nilai Maturitas Manajemen Risiko Satuan Kerja',
    unit: 'nilai',
    targetYearly: '4 Nilai',
    targetNum: 4,
    tw1: '4,14',
    supportLink: 'https://drive.google.com/file/d/1ob8CZNegFJaf6d8svo3cFrMNJbeJiWSJ',
    justification: 'Penilaian mandiri s.d. Maret menunjukkan tingkat kedewasaan manajemen risiko yang matang.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'UPR',
  },
  {
    no: '22',
    name: 'IKD 33.2.1 - Persentase Realisasi Anggaran Satuan Kerja',
    unit: 'persen',
    targetYearly: '96%',
    targetNum: 96,
    tw1: '14,38%',
    supportLink: 'https://drive.google.com/file/d/1LT_F9zlt3GfM3r701Ja5rmY3vYqbQ7Pw',
    justification: 'Realisasi anggaran di triwulan pertama wajar karena fokus pada kontrak pengadaan.',
    kendala: 'Pengadaan barang jasa/alat laboratorium masih proses tender lelang.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '23',
    name: 'IKD 33.1.2 - Persentase Mutasi Pegawai antar Satuan Kerja',
    unit: 'persen',
    targetYearly: '10%',
    targetNum: 10,
    tw1: '0,60%',
    supportLink: 'https://drive.google.com/drive/folders/19ryN8YVcROQ8ABRiRKL444oj10pRiqBr',
    justification: 'Sedang ada penataan mutasi internal dosen untuk pemenuhan keahlian prodi.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Kepegawaian',
  },
];

// Seed raw KPI data (25 items)
const SEED_KPI = [
  {
    no: '1',
    name: 'Persentase EBITDA Margin',
    subName: 'EBITDA Margin Kinerja BLU',
    unit: 'persen',
    targetYearly: '20,36%',
    targetNum: 20.36,
    tw1: '55,52%',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1um_qPMbtzGBQbwxZ_gF_bSdzhPS7jpEv',
    justification: 'Efisiensi biaya dan tingginya serapan SPP di awal tahun membuat EBITDA margin di atas target usulan.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '2',
    name: 'Jumlah Pendapatan BLU',
    subName: 'Semua pendapatan operasional BLU',
    unit: 'rupiah',
    targetYearly: 'Rp 60.859.000.000',
    targetNum: 60859000000,
    tw1: 'Rp 26.196.858.920',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1nNPcO8EfFiYCyHL02DSQIkapO_UgRzaz',
    justification: 'Optimis mencapai target tahunan pasca tagihan UKT Semester genap.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '3',
    name: 'Jumlah Pendapatan BLU dari Optimalisasi Aset dan Kerja Sama',
    subName: 'Penyewaan aset, klinik, dan layanan diklat khusus',
    unit: 'rupiah',
    targetYearly: 'Rp 10.751.317.000',
    targetNum: 10751317000,
    tw1: 'Rp 766.990.000',
    supportLink: 'https://drive.google.com/drive/u/2/folders/1gWq-ovmw2TALO_5v5yxNb_WY7fqjZmfz',
    justification: 'Pendapatan sewa baru dimulai bulan Februari-Maret.',
    kendala: 'Kantin dan fasilitas olahraga baru ramai pasca libur semester mahasiswa.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '4',
    name: 'Persentase Penyelesaian Modernisasi Pengelolaan BLU',
    subName: 'Implementasi tata kelola berbasis sistem digital',
    unit: 'persen',
    targetYearly: '100%',
    targetNum: 100,
    tw1: '68%',
    supportLink: '-',
    justification: 'Integrasi sistem keuangan daerah ke sistem kementerian sedang dikoordinasikan.',
    kendala: 'Pembaruan server dan API integrasi dari PPK-BLU pusat lambat rilis.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '5',
    name: 'Tingkat Perencanaan dan Pengelolaan Rekening Badan Layanan Umum',
    subName: 'Indeks Akurasi Proyeksi Pengesahan Pendapatan dan Belanja BLU',
    unit: 'indeks',
    targetYearly: '3.50',
    targetNum: 3.5,
    tw1: '3.50',
    supportLink: 'https://drive.google.com/file/d/1LT_F9zlt3GfM3r701Ja5rmY3vYqbQ7Pw',
    justification: 'Proyeksi real-time mendekati rencana penggunaan.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '6',
    name: 'Tingkat Perencanaan dan Pengelolaan Rekening Badan Layanan Umum (2)',
    subName: 'Indeks Kualitas Pengelolaan Rekening dan Investasi Jangka Pendek',
    unit: 'indeks',
    targetYearly: '3.50',
    targetNum: 3.5,
    tw1: '3.50',
    supportLink: 'https://drive.google.com/file/d/1LT_F9zlt3GfM3r701Ja5rmY3vYqbQ7Pw',
    justification: 'Rasio cash management dan penempatan deposito jangka pendek di kelola baik.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '7',
    name: 'Indeks Peningkatan Efisiensi Layanan BLU',
    subName: 'Indeks Efisiensi Layanan BLU (RBOL)',
    unit: 'indeks',
    targetYearly: '3.00',
    targetNum: 3.0,
    tw1: '1.50',
    supportLink: '-',
    justification: 'Layanan operasional bertransformasi e-office.',
    kendala: 'Lisensi modul digital masih proses perpindahan server.',
    pjCode: 'Wadir 2',
    pjDetail: 'Keuangan',
  },
  {
    no: '8',
    name: 'Indeks Peningkatan Efisiensi Layanan BLU (2)',
    subName: 'Indeks Pertumbuhan Layanan BLU',
    unit: 'indeks',
    targetYearly: '3.00',
    targetNum: 3.0,
    tw1: '1.50',
    supportLink: '-',
    justification: 'Jumlah pasca uji lab/pelayanan puskesmas meningkat tipis di triwulan pertama.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '9',
    name: 'Kualitas Lulusan',
    subName: 'Persentase jumlah lulusan dengan IPK > 3.50',
    unit: 'persen',
    targetYearly: '67%',
    targetNum: 67,
    tw1: '67%',
    supportLink: 'https://pjm.poltekkespalembang.ac.id/',
    justification: 'Target telah melampaui rata-rata IPK lulusan tahun lalu.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '10',
    name: 'Kualitas Lulusan (2)',
    subName: 'Persentase kelulusan Uji Kompetensi (Ukom)',
    unit: 'persen',
    targetYearly: '97%',
    targetNum: 97,
    tw1: '0%',
    supportLink: 'https://drive.google.com/drive/folders/1ySUxkC1qAlO74h3XaM3GsAzmETZpLaRE',
    justification: 'Ukom first-taker rencananya dilaksanakan di bulan Agustus.',
    kendala: 'Belum ada ujian nasional pada Triwulan 1.',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '11',
    name: 'Kuantitas dan Kualitas Penelitian dan Produk Inovasi',
    subName: 'Penelitian yang dihasilkan',
    unit: 'nilai',
    targetYearly: '235 Nilai',
    targetNum: 235,
    tw1: '50',
    supportLink: 'https://docs.google.com/spreadsheets/d/18nqLg6xSOVKEyA0IKzRwj8NqJ4YwnMxz/edit',
    justification: 'Reviewer eksternal sudah menetapkan proposal dosen untuk skema hibah.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '12',
    name: 'Kuantitas dan Kualitas Penelitian dan Produk Inovasi (2)',
    subName: 'Penelitian yang dipublikasikan',
    unit: 'nilai',
    targetYearly: '315 Nilai',
    targetNum: 315,
    tw1: '14',
    supportLink: 'https://docs.google.com/spreadsheets/d/18nqLg6xSOVKEyA0IKzRwj8NqJ4YwnMxz/edit',
    justification: 'Peneliti mendaftarkan draft ke sinta-2 dan sinta-3.',
    kendala: 'Waktu tunggu penerbitan jurnal internasional bereputasi.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '13',
    name: 'Kuantitas dan Kualitas Penelitian dan Produk Inovasi (3)',
    subName: 'Produk Inovasi yang dihasilkan dan/atau dikomersialisasikan',
    unit: 'nilai',
    targetYearly: '74 Nilai',
    targetNum: 74,
    tw1: '0',
    supportLink: '-',
    justification: 'Hak Paten/Pendaftaran HAKI rata-rata diajukan semester II.',
    kendala: 'Proses paten sederhana di Kemenkumham butuh 3-6 bulan.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '14',
    name: 'Kuantitas dan Kualitas Pengabdian kepada Masyarakat',
    subName: 'Pengabdian Kepada Masyarakat',
    unit: 'nilai',
    targetYearly: '480 Nilai',
    targetNum: 480,
    tw1: '48',
    supportLink: '-',
    justification: 'Proposal pengmas sedang diproses penetapan SK Direktur.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '15',
    name: 'Kuantitas dan Kualitas Pengabdian kepada Masyarakat (2)',
    subName: 'Luaran Pengabdian Kepada Masyarakat',
    unit: 'nilai',
    targetYearly: '365 Nilai',
    targetNum: 365,
    tw1: '0',
    supportLink: '-',
    justification: 'Video luaran pengbadian dan rekap prosiding belum dirilis di youtube/pjm.',
    kendala: 'Menunggu kegiatan pengmas lapangan rampung.',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '16',
    name: 'Kuantitas dan Kualitas Pengabdian kepada Masyarakat (3)',
    subName: 'Jumlah Pembinaan Wilayah Berkelanjutan',
    unit: 'desa',
    targetYearly: '2 Desa/Kel.',
    targetNum: 2,
    tw1: '1',
    supportLink: 'https://drive.google.com/file/d/1LPwWmKhUjdIkW8FzK9odS5Pa6yMPIL8i',
    justification: 'Desa binaan pencegahan stunting di OKU Timur berjalan aktif.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'P2M',
  },
  {
    no: '17',
    name: 'Kuantitas dan Kualitas Dosen',
    subName: 'Persentase Rasio Dosen Tetap terhadap Mahasiswa',
    unit: 'persen',
    targetYearly: '100%',
    targetNum: 100,
    tw1: '100%',
    supportLink: 'https://pjm.poltekkespalembang.ac.id/',
    justification: 'Rasio terpenuhi penuh.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'Akademik',
  },
  {
    no: '18',
    name: 'Kuantitas dan Kualitas Dosen (2)',
    subName: 'Persentase Dosen Tetap dengan Kualifikasi Lektor Kepala dan/atau Guru Besar',
    unit: 'persen',
    targetYearly: '24%',
    targetNum: 24,
    tw1: '23,36%',
    supportLink: 'https://drive.google.com/drive/folders/1CMvMDAAzlzkZtYKYzDr6XC9F178yYCyb',
    justification: 'Beberapa dosen senior sedang proses penilaian tim PAK pusat.',
    kendala: '-',
    pjCode: 'Wadir 2',
    pjDetail: 'Kepegawaian',
  },
  {
    no: '19',
    name: 'Kuantitas dan Kualitas Dosen (3)',
    subName: 'Persentase Dosen Fungsional yang Memiliki Sertifikasi Dosen',
    unit: 'persen',
    targetYearly: '85%',
    targetNum: 85,
    tw1: '81,07%',
    supportLink: 'data_rekap_serdos_tw1.pdf',
    justification: 'Menunggu pembukaan kuota serdos nasional kementerian kesehatan.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'UPM',
  },
  {
    no: '20',
    name: 'Kuantitas dan Kualitas Dosen (4)',
    subName: 'Persentase Dosen Tetap yang Memiliki Kemampuan Berbahasa Inggris',
    unit: 'persen',
    targetYearly: '7%',
    targetNum: 7,
    tw1: '7%',
    supportLink: 'https://drive.google.com/drive/folders/1WvWQUVoKvqYYKgXeevdTe3Oqz4pO5ZzV',
    justification: 'Target tercapai dan dipertahankan melalui sertifikasi IELTS rutin.',
    kendala: '-',
    pjCode: 'Wadir 1',
    pjDetail: 'Pengembangan Bahasa',
  },
];

// Helper to determine numerical achievement value
function parseRealValue(realText: string | null, unit: string): number | null {
  if (!realText) return null;
  const cleaned = realText.replace('%', '').replace(/Rp/gi, '').replace(/,/g, '').replace(/\s/g, '').trim();
  
  // Custom parser if is expression format like 760/1764 = 43.08%
  if (cleaned.includes('=')) {
    const parts = cleaned.split('=');
    const val = parseFloat(parts[1]);
    return isNaN(val) ? null : val;
  }

  // Expression like 1:30
  if (cleaned.includes(':')) {
    return 100; // Standarized met for ratios
  }

  // Expression with details like "48 (15 lokal..."
  const matchNum = cleaned.match(/^(\d+(\.\d+)?)/);
  if (matchNum) {
    return parseFloat(matchNum[1]);
  }

  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

// Prepare combined database achievements
function generateSeedData(): Achievement[] {
  const result: Achievement[] = [];

  // Generate seed IKU
  SEED_IKU.forEach((item, index) => {
    const code = `IKU-${item.no}`;
    const id = `iku-${item.no}`;
    const tw1Val = parseRealValue(item.tw1, item.unit);
    
    // Set realistic monthly trends Jan-Mar
    const mTrend: MonthlyTrend = {
      'Jan': tw1Val ? Math.round(tw1Val * 0.4 * 10) / 10 : null,
      'Feb': tw1Val ? Math.round(tw1Val * 0.7 * 10) / 10 : null,
      'Mar': tw1Val,
      'Apr': null,
      'May': null,
      'Jun': null,
      'Jul': null,
      'Aug': null,
      'Sep': null,
      'Oct': null,
      'Nov': null,
      'Dec': null,
    };

    result.push({
      id,
      type: 'IKU',
      no: item.no,
      code,
      name: item.name,
      unit: item.unit,
      targetYearly: item.targetYearly,
      targetNum: item.targetNum,
      pjCode: item.pjCode,
      pjDetail: item.pjDetail,
      realisation: {
        tw1: item.tw1,
        tw2: null,
        tw3: null,
        tw4: null,
      },
      realValues: {
        tw1: tw1Val,
        tw2: null,
        tw3: null,
        tw4: null,
      },
      monthlyTrend: mTrend,
      supportLink: item.supportLink,
      justification: item.justification,
      kendala: item.kendala,
      lastUpdated: new Date().toISOString(),
    });
  });

  // Generate seed KPI
  SEED_KPI.forEach((item, index) => {
    const code = `KPI-${item.no}`;
    const id = `kpi-${item.no}`;
    const tw1Val = parseRealValue(item.tw1, item.unit);
    
    const mTrend: MonthlyTrend = {
      'Jan': tw1Val ? Math.round(tw1Val * 0.3 * 10) / 10 : null,
      'Feb': tw1Val ? Math.round(tw1Val * 0.8 * 10) / 10 : null,
      'Mar': tw1Val,
      'Apr': null,
      'May': null,
      'Jun': null,
      'Jul': null,
      'Aug': null,
      'Sep': null,
      'Oct': null,
      'Nov': null,
      'Dec': null,
    };

    result.push({
      id,
      type: 'KPI',
      no: item.no,
      code,
      name: item.name,
      subName: item.subName,
      unit: item.unit,
      targetYearly: item.targetYearly,
      targetNum: item.targetNum,
      pjCode: item.pjCode,
      pjDetail: item.pjDetail,
      realisation: {
        tw1: item.tw1,
        tw2: null,
        tw3: null,
        tw4: null,
      },
      realValues: {
        tw1: tw1Val,
        tw2: null,
        tw3: null,
        tw4: null,
      },
      monthlyTrend: mTrend,
      supportLink: item.supportLink,
      justification: item.justification,
      kendala: item.kendala,
      lastUpdated: new Date().toISOString(),
    });
  });

  return result;
}

// Ensure DB exists and is loaded
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

let achievements: Achievement[] = [];
if (fs.existsSync(DB_FILE)) {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    achievements = JSON.parse(raw);
    console.log(`Loaded ${achievements.length} achievements from persisted database.`);
  } catch (err) {
    console.warn("Corruption in db.json, generating seeds...", err);
    achievements = generateSeedData();
    fs.writeFileSync(DB_FILE, JSON.stringify(achievements, null, 2));
  }
} else {
  console.log("No database file found, seeding initial data...");
  achievements = generateSeedData();
  fs.writeFileSync(DB_FILE, JSON.stringify(achievements, null, 2));
}

// Function to save achievements to Disk
function saveToDisk() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(achievements, null, 2));
  } catch (err) {
    console.error("Error saving DB to disk:", err);
  }
}

// --- API ROUTES ---

// Auth
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = USERS.find(u => u.username === username && u.password === password);
  
  if (user) {
    return res.json({
      username: user.username,
      role: user.role,
      pjCode: user.pjCode,
      token: `token-${user.username}-${Date.now()}`,
    });
  } else {
    return res.status(401).json({ error: 'Username atau password salah.' });
  }
});

// Load achievements
app.get('/api/achievements', (req, res) => {
  return res.json(achievements);
});

// Update achievement
app.put('/api/achievements/:id', (req, res) => {
  const { id } = req.params;
  const updateData = req.body;
  const authUser = req.headers['auth-user'] as string;
  const authPj = req.headers['auth-pj'] as string; // 'all', 'Wadir 1', etc.

  // Find index
  const idx = achievements.findIndex(a => a.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Indikator tidak ditemukan.' });
  }

  const indicator = achievements[idx];

  // Simple permission check
  if (authPj !== 'all' && indicator.pjCode !== authPj) {
    return res.status(403).json({ error: 'Anda tidak memiliki hak akses untuk unit kerja ini.' });
  }

  // Update fields
  achievements[idx] = {
    ...indicator,
    ...updateData,
    realValues: {
      tw1: updateData.realisation?.tw1 !== undefined ? parseRealValue(updateData.realisation.tw1, indicator.unit) : indicator.realValues.tw1,
      tw2: updateData.realisation?.tw2 !== undefined ? parseRealValue(updateData.realisation.tw2, indicator.unit) : indicator.realValues.tw2,
      tw3: updateData.realisation?.tw3 !== undefined ? parseRealValue(updateData.realisation.tw3, indicator.unit) : indicator.realValues.tw3,
      tw4: updateData.realisation?.tw4 !== undefined ? parseRealValue(updateData.realisation.tw4, indicator.unit) : indicator.realValues.tw4,
    },
    lastUpdated: new Date().toISOString(),
    updatedBy: authUser || 'anonymous',
  };

  saveToDisk();
  return res.json(achievements[idx]);
});

// Smart early warning system using Gemini
app.post('/api/gemini/analyze', async (req, res) => {
  if (!ai) {
    return res.status(503).json({
      error: 'Fitur analisis pintar AI belum aktif. Masukkan Kunci API Gemini Anda di menu Secrets.',
    });
  }

  const { underperformingData } = req.body;
  if (!underperformingData || underperformingData.length === 0) {
    return res.json({
      recommendations: "Seluruh target kinerja IKU dan KPI Triwulan I Poltekkes Palembang telah terpenuhi dengan baik! Pertahankan capaian dan lakukan monitoring rincian dokumen pendukung secara berkala.",
    });
  }

  // Build high quality Gemini diagnostic prompt
  const itemsText = underperformingData.map((item: any) => (
    `- [${item.code}] ${item.name} (${item.subName || ''}) | Target: ${item.targetYearly} | Capaian saat ini: ${item.realisation.tw1 || '0%'} 
      * Penjelasan divisi: ${item.justification || 'Tidak ada'}
      * Kendala: ${item.kendala || 'Tidak ada'}
      * PJ unit: ${item.pjCode} (${item.pjDetail})`
  )).join('\n');

  const prompt = `Anda adalah sistem pakar Early Warning Kinerja Pendidikan Tinggi Kesehatan (Politeknik Kesehatan Kemenkes Palembang).
Berikut adalah daftar Indikator Kinerja Utama (IKU) dan Key Performance Indicators (KPI) yang belum tercapai atau di bawah performa pada laporan triwulan/bulan ini:

${itemsText}

Tugas Anda:
1. Berikan analisis ringkas, objektif, dan terstruktur mengenai penyebab utama bottleneck/hambatan di Poltekkes Palembang.
2. Berikan rekomendasi konkret, taktis, dan solutif untuk setiap bidang penanggung jawab (misal Wadir I Akademik, Wadir II Kepegawaian/Keuangan, Wadir III Alumni, SPI).
3. Buat nada rekomendasi profesional, menyemangati, dan berorientasi pada solusi cepat (early warning mitigations).
Rekomendasi disajikan dalam Bahasa Indonesia yang santun dan formal.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
    });

    const text = response.text;
    return res.json({ recommendations: text });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    return res.status(500).json({ error: `Gagal memproses rekomendasi AI: ${err.message}` });
  }
});

// Configure Vite middleware or production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
